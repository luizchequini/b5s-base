﻿namespace Base
{
    public class MesCorrespondente
    {
        public string RetornaMesCorrespondente(int mes)
        {
            string _mes = "";

            switch (mes)
            {
                case 1:
                    _mes = "Janeiro";
                    break;
                case 2:
                    _mes = "Fevereiro";
                    break;
                case 3:
                    _mes = "Março";
                    break;
                case 4:
                    _mes = "Abril";
                    break;
                case 5:
                    _mes = "Maio";
                    break;
                case 6:
                    _mes = "Junho";
                    break;
                case 7:
                    _mes = "Julho";
                    break;
                case 8:
                    _mes = "Agosto";
                    break;
                case 9:
                    _mes = "Setembro";
                    break;
                case 10:
                    _mes = "Outubro";
                    break;
                case 11:
                    _mes = "Novembro";
                    break;
                case 12:
                    _mes = "Dezembro";
                    break;
                default:
                    _mes = "Mês desconhecido";
                    break;
            }

            return _mes;
        }
    }
}