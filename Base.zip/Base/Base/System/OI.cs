﻿namespace System
{
    internal class OI
    {
        public static object File { get; internal set; }
    }
}