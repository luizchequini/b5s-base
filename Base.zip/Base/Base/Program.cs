﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Base
{
    class Program
    {
        static void Main(string[] args)
        {
            string opcaoUsuario = ObterOpcaoUsuario();

            do
            {
                switch (opcaoUsuario)
                {
                    case "1":

                        Console.Clear();
                        Console.WriteLine();
                        Console.WriteLine("MÊS CORRESPONDENTE");
                        Console.WriteLine("Digite de 1 a 12 para retornar o mês referente.");
                        Console.WriteLine("S - Sair");

                        do
                        {
                            opcaoUsuario = Console.ReadLine();

                            if (Int32.TryParse(opcaoUsuario, out int j))
                            {
                                Console.WriteLine(MesCorrespondente(j));
                            }
                            else
                            {
                                Console.WriteLine(MesCorrespondente(0));
                            }

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "2":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("MÁDIA SIMPLES");
                            Console.WriteLine("Digite valores numéricos inteiro para cálculo de média simples.");
                            Console.WriteLine("T - Ver cálculo.");

                            List<int> valores = new List<int>();

                            do
                            {
                                opcaoUsuario = Console.ReadLine();

                                if (Int32.TryParse(opcaoUsuario, out int j))
                                {
                                    valores.Add(j);
                                }
                                else
                                {
                                    Console.WriteLine("Valor não numérico.");
                                }

                            } while (!opcaoUsuario.ToUpper().Equals("T"));

                            Console.Clear();

                            if (MediaSimples(valores) == -1)
                            {
                                Console.WriteLine("False");
                            }
                            else
                            {
                                Console.WriteLine("Média: " + MediaSimples(valores));
                            }

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar ao cálculo de média simples ?");
                            Console.WriteLine("S - Sair.");
                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "3":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("RETORNA QUANTIDADE DE NÚMEROS PARES.");
                            Console.WriteLine("Digite valores numéricos inteiro e maior que zero para retornar a quantidade de números pares.");
                            Console.WriteLine();

                            List<int> valores = new List<int>();

                            opcaoUsuario = Console.ReadLine();

                            var valoress = opcaoUsuario.Split(",");

                            Console.Clear();

                            Console.WriteLine("Quantidade de números pares: " + ParOuImpar(valoress));

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar para verificar quantidade de numeros pares ?");
                            Console.WriteLine("S - Sair.");
                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "4":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("INVERTER STRING");
                            Console.WriteLine("Digite um texto qualquer e o veja invertido.");
                            Console.WriteLine();

                            opcaoUsuario = Console.ReadLine();

                            Console.Clear();

                            Console.WriteLine(InverterString(opcaoUsuario));

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar a inverter texto.");
                            Console.WriteLine("S - Sair.");
                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "5":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("SUBSTITUIR VOGAIS");
                            Console.WriteLine("Digite um texto qualquer para substituição das vogais.");
                            Console.WriteLine();

                            opcaoUsuario = Console.ReadLine();

                            Console.Clear();

                            Console.WriteLine(SubstituirCaracteres(opcaoUsuario));

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar a inverter texto.");
                            Console.WriteLine("S - Sair.");
                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "6":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("ORDENA ARRAY");
                            Console.WriteLine("Digite texto com dígitos numéricos separado por vígulas para ser ordenado dentro de um Array.");
                            Console.WriteLine();

                            opcaoUsuario = Console.ReadLine();

                            Console.Clear();

                            var array = opcaoUsuario.Split(",");

                            string b = string.Empty;

                            foreach (var item in OrdenarArray(array))
                            {
                                b += item;
                            }

                            Console.WriteLine(b);

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar a inverter texto.");
                            Console.WriteLine("S - Sair.");
                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "7":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("PRIMEIRO NÃO REPETIDO");
                            Console.WriteLine("Digite texto com dígitos numéricos separado por vígulas para retornar o primeiro numero não repetido.");
                            Console.WriteLine();

                            opcaoUsuario = Console.ReadLine();
                            
                            Console.Clear();

                            Console.WriteLine(PrimeiroNumeroNaoRepetido(opcaoUsuario));

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar a inverter texto.");
                            Console.WriteLine("S - Sair.");
                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    case "8":

                        do
                        {
                            Console.Clear();
                            Console.WriteLine();
                            Console.WriteLine("MANIPULAÇÃO ARQUIVO");
                            Console.WriteLine("Digite um texto contendo 0 e 1 e veja.");
                            Console.WriteLine("Se a quantidade de 0 é multiplo de 3.");
                            Console.WriteLine("Se a quantidade de 1 é multiplo de 2.");
                            Console.WriteLine("S - Sair.");

                            opcaoUsuario = Console.ReadLine();

                            ManipulacaoArquivoCriar(opcaoUsuario);

                            Console.Clear();

                            ManipulacaoArquivo();

                            Console.WriteLine();
                            Console.WriteLine("Enter para voltar a manipular arquivo.");
                            Console.WriteLine("S - Sair.");

                            opcaoUsuario = Console.ReadLine();

                        } while (!opcaoUsuario.ToUpper().Equals("S"));

                        Console.Clear();

                        opcaoUsuario = ObterOpcaoUsuario();

                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Opção inválida");
                        opcaoUsuario = ObterOpcaoUsuario();
                        break;
                }

            } while (opcaoUsuario.ToUpper() != "S");
        }

        private static string ObterOpcaoUsuario()
        {
            Console.WriteLine();
            Console.WriteLine("B5S EXERCÍCIOS BASE");
            Console.WriteLine("DESENVOLVIMENTO LUIZ CHEQUINI");
            Console.WriteLine("Informe a opção desejada");
            Console.WriteLine();
            Console.WriteLine("1 - Mês correspondente");
            Console.WriteLine("2 - Média simples");
            Console.WriteLine("3 - Retorna quantidade de números pares");
            Console.WriteLine("4 - Inverter string");
            Console.WriteLine("5 - Substituir vogais");
            Console.WriteLine("6 - Ordenar array");
            Console.WriteLine("7 - Primeiro número não repetidos");
            Console.WriteLine("8 - Manipulacao arquivos");
            Console.WriteLine("S - Sair");
            Console.WriteLine();

            string opcaoUsuario = Console.ReadLine().ToUpper();
            Console.WriteLine();
            return opcaoUsuario;
        }

        public static string MesCorrespondente(int mes)
        {
            string retornoMes;

            switch (mes)
            {
                case 1:
                    retornoMes = "Janeiro";
                    break;
                case 2:
                    retornoMes = "Fevereiro";
                    break;
                case 3:
                    retornoMes = "Março";
                    break;
                case 4:
                    retornoMes = "Abril";
                    break;
                case 5:
                    retornoMes = "Maio";
                    break;
                case 6:
                    retornoMes = "Junho";
                    break;
                case 7:
                    retornoMes = "Julho";
                    break;
                case 8:
                    retornoMes = "Agosto";
                    break;
                case 9:
                    retornoMes = "Setembro";
                    break;
                case 10:
                    retornoMes = "Outubro";
                    break;
                case 11:
                    retornoMes = "Novembro";
                    break;
                case 12:
                    retornoMes = "Dezembro";
                    break;
                default:
                    retornoMes = "Mês desconhecido";
                    break;
            }

            return retornoMes;
        }

        public static int MediaSimples(List<int> valores)
        {
            int temPeloMenos3Itens = valores.Count;
            int somaValores = 0;

            if (temPeloMenos3Itens >= 3)
            {
                foreach (int valor in valores)
                {
                    somaValores += valor;
                }
            }
            else
            {
                return -1;
            }

            return somaValores / temPeloMenos3Itens;
        }

        public static int ParOuImpar(string[] valores)
        {
            int quantidadeDeNumerosPares = 0;

            foreach (var valor in valores)
            {
                if (Int32.TryParse(valor, out int j))
                {
                    if (j % 2 == 0)
                    {
                        quantidadeDeNumerosPares++;
                    }
                }
            }

            return quantidadeDeNumerosPares;
        }

        public static string InverterString(string texto)
        {

            Array letras = texto.ToArray();
            Array.Reverse(letras);

            texto = string.Empty;

            foreach (char letra in letras)
            {
                texto += letra.ToString();
            }

            return texto;
        }

        public static string SubstituirCaracteres(string texto)
        {
            string novoTexto = texto.Replace('A', '?')
                                    .Replace('E', '?')
                                    .Replace('I', '?')
                                    .Replace('O', '?')
                                    .Replace('U', '?')
                                    .Replace('a', '?')
                                    .Replace('e', '?')
                                    .Replace('i', '?')
                                    .Replace('o', '?')
                                    .Replace('u', '?');

            return novoTexto;
        }

        public static string[] OrdenarArray(string[] array)
        {
            string[] vetor = array;
            int aux;

            for (int i = 0; i < array.Length; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    Int32.TryParse(vetor[i], out int a);
                    Int32.TryParse(vetor[j], out int b);


                    if (a > b)
                    {
                        aux = a;
                        vetor[i] = vetor[j];
                        vetor[j] = aux.ToString();
                    }
                }

            }

            return vetor;
        }

        public static int PrimeiroNumeroNaoRepetido(string valores)
        {
            string[] vetor = valores.Split(",");
            string[] vetorAux = valores.Split(",");
            int aux;
            int cont = 0;

            for (int i = 0; i < vetor.Length; i++)
            {
                for (int j = i + 1; j < vetor.Length; j++)
                {

                    Int32.TryParse(vetor[i], out int a);
                    Int32.TryParse(vetor[j], out int b);

                    if (a == b && !vetorAux[j].Equals("Repetido"))
                    {
                        cont++;
                        vetorAux[j] = "Repetido";
                        vetorAux[i] = "Repetido";
                    }
                }

                if (!vetorAux[i].Equals("Repetido"))
                {
                    Int32.TryParse(vetor[i], out int j);
                    return j;
                }

            }

            return -1;
        }

        public static void ManipulacaoArquivo()
        {
            string[] linhas = File.ReadAllLines("data.dat");

            int count2 = 0;
            int count3 = 0;

            foreach (var linha in linhas)
            {
                for (int i = 0; i < linha.Length; i++)
                {
                    if (linha[i] % 2 == 0)
                    {
                        count3++;
                    }
                    else
                    {
                        count2++;
                    }
                }
            }

            if (count2 % 2 == 0 && count2 != 0)
            {
                Console.WriteLine("A quantidade de números 1 é um multiplo de 2");
            }
            else
            {
                Console.WriteLine("Não contém multiplo de 2");
            }

            if (count3 % 3 == 0 && count3 != 0)
            {
                Console.WriteLine("A quantidade de números zeros na linha é um multiplo de 3");
            }
            else
            {
                Console.WriteLine("Não contém multiplo de 3");
            }
        }

        public static void ManipulacaoArquivoCriar(string texto)
        {
            File.WriteAllText("data.dat", texto);
        }
    }
}
